npm install express mongoose bcrypt multer

# install mongodb
# brew tap mongodb/brew
# brew install mongodb-community
# brew services start mongodb-community
