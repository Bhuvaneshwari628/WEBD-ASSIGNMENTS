import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import About from './components/about';
import Contact from './components/contact';
import Home from '/components/home';
import JobListings from './components/joblistings';
import Login from './components/login';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/login" element={<Login />} />            
          <Route path="/about" element={<About />} />
          <Route path="/joblistings" element={<JobListings />} />                                      
          <Route path="/contact" element={<Contact />} />                                          
          <Route path="/" element={<Home />} /> {/* Optional Home Route */}                                        
        </Routes>
      </div>                                                                                      
    </Router>
  );
}

export default App;
