import React from 'react';
import './about.css';

function About() {
  return (
    <div className="about">
      <h2>About Us</h2>
      <p>Welcome to the Job Portal! Our platform connects job seekers with their ideal roles, making the job search process easier and more efficient. Learn more about our mission and the services we provide.</p>
    </div>
  );
}

export default About;
