import React from 'react';
import { useNavigate } from 'react-router-dom';
import './home.css';

function Home() {
  const navigate = useNavigate();

  const handleBrowseJobs = () => {
    navigate('/joblistings'); // Assumes /joblistings route is set for JobListings component
  };

  return (
    <div className="home">
      <h1>Welcome to the Job Portal</h1>
      <p>Discover job opportunities that match your skills and interests. Start your journey with us today!</p>
      <button className="browse-jobs-btn" onClick={handleBrowseJobs}>
        Browse Jobs
      </button>
    </div>
  );
}
   
export default Home;
