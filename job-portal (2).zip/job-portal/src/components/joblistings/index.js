import React from 'react';
import './joblistings.css';

const jobPosts = [
  { id: 1, title: 'Full Stack Developer', description: 'Develop cutting-edge web applications.' },
  { id: 2, title: 'Data Scientist', description: 'Analyze data to derive actionable insights.' },
  { id: 3, title: 'UI/UX Designer', description: 'Design user-friendly interfaces and experiences.' },
];

function JobListings() {
  return (
    <div className="job-listings">
      <h2>Job Listings</h2>
      <ul>
        {jobPosts.map((job) => (
          <li key={job.id}>
            <h3>{job.title}</h3>
            <p>{job.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default JobListings;
