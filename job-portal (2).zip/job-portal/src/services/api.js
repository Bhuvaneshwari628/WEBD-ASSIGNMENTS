import axios from 'axios';

// Set the base URL for the API
const API_BASE_URL = 'http://localhost:3000/api'; // Replace with your actual API URL

// Configure Axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Login function
export const login = async (credentials) => {
  try {
    const response = await api.post('/login', credentials);
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

// Fetch job listings
export const fetchJobListings = async () => {
  try {
    const response = await api.get('/joblistings');
    return response.data;
  } catch (error) {
    console.error('Fetch job listings error:', error);
    throw error;
  }
};

// Fetch about page data
export const fetchAbout = async () => {
  try {
    const response = await api.get('/about');
    return response.data;
  } catch (error) {
    console.error('Fetch about data error:', error);
    throw error;
  }
};

// Contact form submission
export const submitContactForm = async (formData) => {
  try {
    const response = await api.post('/contact', formData);
    return response.data;
  } catch (error) {
    console.error('Contact form submission error:', error);
    throw error;
  }
};

// You can add more functions here as needed for other API calls

